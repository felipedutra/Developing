#include "Competicao.h"
#include <stdexcept>

// Implemente as alteracoes

Competicao::Competicao(string nome, int maxValor) :
nome(nome), maxValor(maxValor) {
    quantidadeDeModalidades = 0;
   // equipes = new Equipe*[maxValor];
   equipes = new vector <Equipe*> ();

    modalidades = new Modalidade*[maxValor];
    //cout << "Criou " <<endl;
}

Competicao::~Competicao() {
	delete[] equipes;
	while (!equipes->empty()) {
        Equipe * ultimo = equipes->back();
        equipes->pop_back();
        delete ultimo;
	}
	delete equipes;
	delete[] modalidades;
}

int Competicao::getQuantidadeDeModalidades() {
    return quantidadeDeModalidades;
}

vector<Equipe*>* Competicao::getEquipes() {
    return equipes;
}




Modalidade** Competicao::getModalidades() {
    return modalidades;
}

void Competicao::adicionar(Equipe* e) {
    unsigned int tamanhoAtual = equipes->size();
    if (tamanhoAtual >= maxValor) throw new overflow_error ("Overflow");
    for(unsigned int i = 0; i < equipes->size(); i++) {
        if(equipes->at(i) == e) throw new invalid_argument("Equipe ja adicionada");
    }
    equipes->push_back ( e );
   // cout << "Adicionou" <<endl;
}

void Competicao::adicionar(Modalidade* m) {
    if(quantidadeDeModalidades >= maxValor) throw new overflow_error("Modalidades esta cheio");
    for(int i = 0; i < quantidadeDeModalidades; i++) {
        if(modalidades[i] == m) throw new invalid_argument("Modalidade ja adicionada");
    }
    modalidades[quantidadeDeModalidades] = m;
    quantidadeDeModalidades++;
}
