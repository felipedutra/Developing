#include "Competicao.h"
#include <stdexcept>

// Implemente as alteracoes

Competicao::Competicao(string nome, int maxValor) :
nome(nome), maxValor(maxValor) {
    quantidadeDeModalidades = 0;
    quantidadeDeEquipes = 0;
    equipes = new Equipe*[maxValor];
    modalidades = new Modalidade*[maxValor];
}

Competicao::~Competicao() {
	delete[] equipes;
	delete[] modalidades;
}

int Competicao::getQuantidadeDeModalidades() {
    return quantidadeDeModalidades;
}

int Competicao::getQuantidadeDeEquipes() {
    return quantidadeDeEquipes;
}

Equipe** Competicao::getEquipes() {
    return equipes;
}

Modalidade** Competicao::getModalidades() {
    return modalidades;
}

void Competicao::adicionar(Equipe* e) {
    if(quantidadeDeEquipes >= maxValor) throw new overflow_error("Equipes esta cheio");
    for(int i = 0; i < quantidadeDeEquipes; i++) {
        if(equipes[i] == e) throw new invalid_argument("Equipe ja adicionada");
    }
    equipes[quantidadeDeEquipes] = e;
    quantidadeDeEquipes++;
}

void Competicao::adicionar(Modalidade* m) {
    if(quantidadeDeModalidades >= maxValor) throw new overflow_error("Modalidades esta cheio");
    for(int i = 0; i < quantidadeDeModalidades; i++) {
        if(modalidades[i] == m) throw new invalid_argument("Modalidade ja adicionada");
    }
    modalidades[quantidadeDeModalidades] = m;
    quantidadeDeModalidades++;
}
