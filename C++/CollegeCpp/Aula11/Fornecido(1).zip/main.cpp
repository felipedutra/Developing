#include <iostream>

using namespace std;

// Faca os testes aqui
int main() {
    return 0;
}
