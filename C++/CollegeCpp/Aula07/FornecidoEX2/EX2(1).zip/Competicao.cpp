#include "Competicao.h"

Competicao::Competicao(string nome, int maximoValor) :
nome(nome), maximoValor(maximoValor) {
    quantidadeDeEquipes = 0;
    equipes = new Equipe*[maximoValor];
    modalidades = new Modalidade*[maximoValor];
}

Competicao::~Competicao() {
    delete[] equipes;
}

int Competicao::getQuantidadeDeEquipes() {
    return quantidadeDeEquipes;
}

int Competicao::getQuantidadeDeModalidades() {
    return quantidadeDeModalidades;
}

Equipe** Competicao::getEquipes() {
    return equipes;
}

Modalidade** Competicao::getModalidades() {
    return modalidades;
}

bool Competicao::adicionar(Equipe* e) {
    if(quantidadeDeEquipes >= maximoValor) return false;
    for(int i = 0; i < quantidadeDeEquipes; i++) {
        if(equipes[i] == e) return false;
    }
    equipes[quantidadeDeEquipes] = e;
    quantidadeDeEquipes++;
    return true;
}
bool  Competicao::adicionar(Modalidade* m) {
    if (quantidadeDeModalidades >= maximoValor) return false;
    bool verdade;
    for(int i = 0; i < quantidadeDeModalidades; i++) {
        if(modalidades[i] == m) return false;
    }
    for (int i = 0; i < m->getQuantidade(); i++) {
        bool existe = false;
        for (int j = 0; j < quantidadeDeEquipes ; j ++) {
               if( m->getEquipes()[i] ==equipes[j]) existe = true;
        }
        if (existe == false) {
           return false;

        }
    }
    modalidades[quantidadeDeModalidades] = m;
    quantidadeDeModalidades++;

    return true;
}


void Competicao::imprimir() {
    cout << "Competicao " << nome << endl;

//    CompeticaoImprimivel::imprimir();  // Como chamar um m�todo de uma derivada?

}
