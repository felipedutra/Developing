#include "PersistenciaEquipe.h"
#include <fstream>

 PersistenciaEquipe::PersistenciaEquipe(string arquivo) {

     this->arquivo = arquivo;
}
PersistenciaEquipe::~PersistenciaEquipe() {

}

void PersistenciaEquipe::inserir(Equipe *e) {



    ofstream output;
    output.open(arquivo, ios::app);
    output << e->getNome()  <<endl;
    output << e->getMembros() <<endl;
    output.close();


}
