#include "Modalidade.h"

Modalidade::Modalidade(string nome, int maximoEquipes) :
        nome(nome), maximoEquipes(maximoEquipes) {

    quantidade = 0;

    if (maximoEquipes <= 1 || nome.empty()) {
        throw new invalid_argument ("Nome vazio");
    }

    equipes = new Equipe*[maximoEquipes];
}

Modalidade::~Modalidade() {
    delete[] equipes;
}

void Modalidade::adicionar(Equipe* e) {
    if(quantidade >= maximoEquipes)
        throw new overflow_error ("Overflow");

    equipes[quantidade] = e;
    quantidade++;

}


string Modalidade::getNome() {
    return nome;
}

int Modalidade::getQuantidade() {
    return quantidade;
}

void Modalidade::imprimir() {
    for(int i = 0; i < quantidade; i++) {
        equipes[i]->imprimir();
    }
}
